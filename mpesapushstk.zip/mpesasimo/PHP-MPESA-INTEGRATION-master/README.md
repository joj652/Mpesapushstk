## PHP M-PESA INTEGRATION

This is a github repository on the youtube video about how to integrate M-PESA into your PHP application. I did this after doing a Tutorial on how to integrate M-PESA into a Laravel application and many people requested that I should do the same using core PHP.

## About

This is a tutorial on how to integrate M-PESA into a core PHP application!

## How to use this repository

Just clone this project, create a new application in your safaricom developer's portal, replace the details in MpesaProcessor.php file then test.
